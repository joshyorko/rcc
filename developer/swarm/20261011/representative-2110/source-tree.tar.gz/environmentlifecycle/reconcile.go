package environmentlifecycle

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"strings"

	"github.com/joshyorko/rcc/environmentartifact"
)

type LeaseStatus string

const (
	LeaseActive    LeaseStatus = "active"
	LeaseStale     LeaseStatus = "stale"
	LeaseAmbiguous LeaseStatus = "ambiguous"
)

var ErrActiveLease = errors.New("active lifecycle lease")

type ReconcileReport struct {
	ArtifactDigest           environmentartifact.Digest
	Active, Stale, Ambiguous int
	Repaired                 []string
	Items                    []ReconcileItem
	Provisional              int `json:"provisional,omitempty"`
	ProvisionalRemoved       int `json:"provisionalRemoved,omitempty"`
}

type ReconcileItem struct {
	ID       string      `json:"id"`
	Status   LeaseStatus `json:"status"`
	Reason   string      `json:"reason"`
	Repaired bool        `json:"repaired"`
}

var reconcileAfterValidationHook func(environmentartifact.Digest) error

func classifyLease(lease Lease) LeaseStatus {
	if lease.OwnerPID <= 0 || lease.OwnerStart == "" {
		return LeaseAmbiguous
	}
	identity, err := processIdentityLookup(lease.OwnerPID)
	if err != nil {
		if os.IsNotExist(err) {
			return LeaseStale
		}
		return LeaseAmbiguous
	}
	if identity == "" {
		return LeaseAmbiguous
	}
	if identity != lease.OwnerStart {
		return LeaseStale
	}
	return LeaseActive
}

func Reconcile(ctx context.Context, digest environmentartifact.Digest) (ReconcileReport, error) {
	var report ReconcileReport
	err := withArtifactTransaction(ctx, digest, func(ctx context.Context) error {
		var err error
		report, err = reconcileLocked(ctx, digest)
		return err
	})
	return report, err
}

func reconcileLocked(ctx context.Context, digest environmentartifact.Digest) (ReconcileReport, error) {
	return reconcileLockedWithRepair(ctx, digest, true)
}

func reconcileLockedWithRepair(ctx context.Context, digest environmentartifact.Digest, repair bool) (ReconcileReport, error) {
	if err := ctx.Err(); err != nil {
		return ReconcileReport{}, err
	}
	report := ReconcileReport{ArtifactDigest: digest}
	if err := validateProvisionalRecords(digest); err != nil {
		return report, err
	}
	if reconcileAfterValidationHook != nil {
		if err := reconcileAfterValidationHook(digest); err != nil {
			return report, err
		}
	}
	for _, state := range []materializationState{stateVerifiedContent, stateMaterializing} {
		components := recordComponents(digest, state)
		_, readErr := readRegularNoFollow(recordRoot(), components, maxMaterializationRecordBytes)
		if readErr == nil {
			report.Provisional++
			// These records are transactional intent, never readiness. Remove the
			// journal entry after a crash; the ready record remains authoritative.
			if repair {
				if err := removeRegularNoFollow(recordRoot(), components); err != nil && !os.IsNotExist(err) {
					return report, err
				}
				report.ProvisionalRemoved++
			}
		} else if !os.IsNotExist(readErr) {
			return report, readErr
		}
	}
	dir := filepath.Join(recordRoot(), digest.Hex(), "leases")
	entries, err := os.ReadDir(dir)
	if os.IsNotExist(err) {
		return report, nil
	}
	if err != nil {
		return report, err
	}
	for _, entry := range entries {
		if ctx.Err() != nil {
			return report, ctx.Err()
		}
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".json") {
			continue
		}
		id := strings.TrimSuffix(entry.Name(), ".json")
		lease, err := readLease(digest, id)
		if err != nil {
			report.Ambiguous++
			report.Items = append(report.Items, ReconcileItem{ID: id, Status: LeaseAmbiguous, Reason: "malformed-or-noncanonical-lease"})
			continue
		}
		switch classifyLease(lease) {
		case LeaseActive:
			report.Active++
			report.Items = append(report.Items, ReconcileItem{ID: id, Status: LeaseActive, Reason: "owner-identity-matches"})
		case LeaseStale:
			report.Stale++
			if repair {
				if err := removeRegularNoFollow(recordRoot(), leaseComponents(digest, id)); err != nil && !os.IsNotExist(err) {
					return report, err
				}
				report.Repaired = append(report.Repaired, id)
			}
			report.Items = append(report.Items, ReconcileItem{ID: id, Status: LeaseStale, Reason: "owner-missing-or-pid-reused", Repaired: repair})
		case LeaseAmbiguous:
			report.Ambiguous++
			report.Items = append(report.Items, ReconcileItem{ID: id, Status: LeaseAmbiguous, Reason: "owner-identity-unavailable-or-ambiguous"})
		}
	}
	return report, nil
}
